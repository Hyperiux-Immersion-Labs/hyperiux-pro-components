"use client";

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ChevronDown, ChevronRight } from "lucide-react";

const DEFAULT_MENU_ITEMS = [
  {
    name: "Effects",
    href: "#",
    isDropdown: true,
    dropdown: [
      { title: "All Effects", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-09.jpg", href: "#" },
      { title: "Components", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-10.jpg", href: "#" },
      { title: "WebGL", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-11.jpg", href: "#" },
    ],
  },
  {
    name: "Tech",
    href: "/tech",
    isDropdown: true,
    dropdown: [
      { title: "React Effects", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-01.jpg", href: "#" },
      { title: "GSAP Effects", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-02.jpg", href: "#" },
      { title: "Three.js Effects", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-03.jpg", href: "#" },
    ],
  },
  {
    name: "Extras",
    href: "#",
    isDropdown: false,
    dropdown: null,
  },
  {
    name: "Docs",
    href: "#",
    isDropdown: true,
    dropdown: [
      { title: "Introduction", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-05.jpg", href: "#" },
      { title: "Installation", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-06.jpg", href: "#" },
      { title: "CLI", img: "https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/vault-listing-images/assets-images/h-07.jpg", href: "#" },
    ],
  },
];

const DROPDOWN_ITEM_OFFSET_Y = -8;
const NAV_TEXT_DURATION = 0.35;
const CTA_DURATION = 0.4;
const DROPDOWN_POINTER_DELAY = 0.03;

const DIMMED_TEXT_COLOR = "rgba(255,255,255,0.5)";
const ACTIVE_TEXT_COLOR = "rgba(255,255,255,1)";
const DEFAULT_CTA_BACKGROUND = "#fff";
const HOVER_CTA_BACKGROUND = "#000";

const DEFAULT_CTA = {
  label: "BUILT W/ HYPERIUX",
  href: "#",
};

/**
 * @typedef {Object} ElevateDropdownItem
 * @property {string} title
 * @property {string} img
 * @property {string} href
 */

/**
 * @typedef {Object} ElevateMenuItem
 * @property {string} name
 * @property {string} href
 * @property {boolean} isDropdown
 * @property {ElevateDropdownItem[] | null} [dropdown]
 */

/**
 * @typedef {Object} ElevateCta
 * @property {string} label
 * @property {string} href
 */

/**
 * @typedef {Object} ElevateTextSwapData
 * @property {Element|null} defaultText
 * @property {Element|null} hoverText
 */

/**
 * @typedef {Object} ElevateNavbarDesktopProps
 * @property {ElevateMenuItem[]} [menuItems]
 * @property {ElevateCta} [cta]
 */

/** @param {ElevateNavbarDesktopProps} props */
export function ElevateNavbarDesktop({
  menuItems = DEFAULT_MENU_ITEMS,
  cta = DEFAULT_CTA,
  navTextDuration = NAV_TEXT_DURATION,
  ctaDuration = CTA_DURATION,
  activeColor = ACTIVE_TEXT_COLOR,
  inactiveColor = DIMMED_TEXT_COLOR,
  ease = "power2.out",
  dropdownItemOffsetY = DROPDOWN_ITEM_OFFSET_Y,
  dropdownPointerDelay = DROPDOWN_POINTER_DELAY,
  staggerItems = true,
  ctaBackground = DEFAULT_CTA_BACKGROUND,
  ctaHoverBackground = HOVER_CTA_BACKGROUND,
}) {
  const navWrapRef = useRef(/** @type {HTMLDivElement|null} */ (null));
  const navLinksRef = useRef(/** @type {(HTMLAnchorElement|null)[]} */ ([]));
  const ctaRef = useRef(/** @type {HTMLAnchorElement|null} */ (null));
  const dropdownRef = useRef(/** @type {HTMLDivElement|null} */ (null));
  const dropdownItemsRef = useRef(/** @type {(HTMLDivElement|null)[]} */ ([]));
  const dropdownTextDataRef = useRef(/** @type {(ElevateTextSwapData|null)[]} */ ([]));
  const linkDataRef = useRef(/** @type {(ElevateTextSwapData|null)[]} */ ([]));

  const activeDropdownIndexRef = useRef(/** @type {number|null} */ (null));
  const isPointerInsideDropdownRef = useRef(false);
  const hideCallRef = useRef(/** @type {gsap.core.Tween|null} */ (null));
  const switchTweenRef = useRef(/** @type {gsap.core.Tween|null} */ (null));
  const itemTweenRef = useRef(/** @type {gsap.core.Timeline|gsap.core.Tween|null} */ (null));

  const [renderedDropdownIndex, setRenderedDropdownIndexState] = useState(/** @type {number|null} */ (null));
  const [activeChevronIndex, setActiveChevronIndex] = useState(/** @type {number|null} */ (null));
  const reduceMotion = useCallback(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches === true,
    []
  );

  const killHideCall = useCallback(() => {
    if (!hideCallRef.current) return;

    hideCallRef.current.kill();
    hideCallRef.current = null;
  }, []);

  const killSwitchTween = useCallback(() => {
    if (!switchTweenRef.current) return;

    switchTweenRef.current.kill();
    switchTweenRef.current = null;
  }, []);

  const killItemTween = useCallback(() => {
    if (!itemTweenRef.current) return;

    itemTweenRef.current.kill();
    itemTweenRef.current = null;
  }, []);

  const getCurrentDropdownItems = useCallback(() => {
    return /** @type {HTMLDivElement[]} */ (dropdownItemsRef.current.filter(Boolean));
  }, []);

  const setRenderedDropdownIndex = useCallback((/** @type {number|null} */ index) => {
    dropdownItemsRef.current = [];
    dropdownTextDataRef.current = [];
    setRenderedDropdownIndexState(index);
  }, []);

  const showWrapper = useCallback(() => {
    if (!dropdownRef.current) return;

    gsap.set(dropdownRef.current, {
      autoAlpha: 1,
      pointerEvents: "auto",
    });
  }, []);

  const hideWrapper = useCallback(() => {
    if (!dropdownRef.current) return;

    gsap.set(dropdownRef.current, {
      autoAlpha: 0,
      pointerEvents: "none",
    });
  }, []);

  const setNavVisualState = useCallback((/** @type {number|null} */ activeIndex) => {
    navLinksRef.current.forEach((linkElement, index) => {
      if (!linkElement) return;

      const color =
        activeIndex !== null && index !== activeIndex
          ? inactiveColor
          : activeColor;

      if (reduceMotion()) {
        gsap.set(linkElement, { color });
        return;
      }

      gsap.to(linkElement, {
        color,
        duration: navTextDuration,
        ease,
        overwrite: true,
      });
    });
  }, [activeColor, ease, inactiveColor, navTextDuration, reduceMotion]);

  const animateTextSwap = useCallback((/** @type {ElevateTextSwapData|null} */ item, /** @type {boolean} */ isEntering) => {
    if (!item) return;

    if (reduceMotion()) {
      gsap.set(item.defaultText, { yPercent: 0 });
      gsap.set(item.hoverText, { yPercent: 100 });
      return;
    }

    gsap
      .timeline({
        defaults: {
          duration: navTextDuration,
          ease,
          overwrite: true,
        },
      })
      .to(item.defaultText, { yPercent: isEntering ? -100 : 0 }, 0)
      .to(item.hoverText, { yPercent: isEntering ? 0 : 100 }, 0);
  }, [ease, navTextDuration, reduceMotion]);

  const initDropdownItemText = useCallback(() => {
    dropdownTextDataRef.current = dropdownItemsRef.current.map((itemElement) => {
      if (!itemElement) return null;

      return {
        defaultText: itemElement.querySelector("[data-default]"),
        hoverText: itemElement.querySelector("[data-hover]"),
      };
    });

    dropdownTextDataRef.current.forEach((item) => {
      if (!item) return;

      gsap.set(item.defaultText, { yPercent: 0 });
      gsap.set(item.hoverText, { yPercent: 100 });
    });
  }, []);

  const animateDropdownItemsIn = useCallback(() => {
    const dropdownItems = getCurrentDropdownItems();

    if (!dropdownItems.length) return;

    killItemTween();
    gsap.killTweensOf(dropdownItems);

    if (reduceMotion()) {
      gsap.set(dropdownItems, {
        opacity: 1,
        y: 0,
        pointerEvents: "auto",
      });
      return;
    }

    gsap.set(dropdownItems, {
      opacity: 0,
      y: dropdownItemOffsetY,
      pointerEvents: "auto",
    });

    itemTweenRef.current = gsap.timeline({
      overwrite: true,
    });

    itemTweenRef.current.to(dropdownItems, {
      y: 0,
      opacity: 1,
      duration: navTextDuration,
      stagger: staggerItems ? 0.025 : 0,
      ease,
    });
  }, [dropdownItemOffsetY, ease, getCurrentDropdownItems, killItemTween, navTextDuration, reduceMotion, staggerItems]);

  const animateDropdownItemsOut = useCallback(
    (/** @type {(() => void)|undefined} */ onComplete) => {
      const dropdownItems = getCurrentDropdownItems();

      if (!dropdownItems.length) {
        onComplete?.();
        return;
      }

      killItemTween();
      gsap.killTweensOf(dropdownItems);

      if (reduceMotion()) {
        gsap.set(dropdownItems, {
          y: dropdownItemOffsetY,
          opacity: 0,
          pointerEvents: "none",
        });
        onComplete?.();
        return;
      }

      itemTweenRef.current = gsap.timeline({
        overwrite: true,
        onStart: () => {
          gsap.set(dropdownItems, {
            pointerEvents: "none",
          });
        },
        onComplete,
      });

      itemTweenRef.current.to(dropdownItems, {
        y: dropdownItemOffsetY,
        opacity: 0,
        duration: navTextDuration,
        stagger: staggerItems ? 0.015 : 0,
        ease,
      });
    },
    [dropdownItemOffsetY, ease, getCurrentDropdownItems, killItemTween, navTextDuration, reduceMotion, staggerItems]
  );

  const closeDropdown = useCallback(() => {
    killHideCall();
    killSwitchTween();

    activeDropdownIndexRef.current = null;
    setActiveChevronIndex(null);

    animateDropdownItemsOut(() => {
      if (
        activeDropdownIndexRef.current !== null ||
        isPointerInsideDropdownRef.current
      ) {
        return;
      }

      setRenderedDropdownIndex(null);
      hideWrapper();
    });
  }, [
    animateDropdownItemsOut,
    hideWrapper,
    killHideCall,
    killSwitchTween,
    setRenderedDropdownIndex,
  ]);

  const openDropdownForIndex = useCallback(
    (/** @type {number} */ index) => {
      const menuItem = menuItems[index];

      killHideCall();
      killSwitchTween();

      if (!menuItem?.isDropdown) return;

      activeDropdownIndexRef.current = index;
      isPointerInsideDropdownRef.current = false;

      showWrapper();

      if (renderedDropdownIndex === null) {
        setRenderedDropdownIndex(index);
        return;
      }

      if (renderedDropdownIndex === index) {
        const dropdownItems = getCurrentDropdownItems();

        if (!dropdownItems.length) return;

        killItemTween();
        gsap.killTweensOf(dropdownItems);

        if (reduceMotion()) {
          gsap.set(dropdownItems, {
            y: 0,
            opacity: 1,
            pointerEvents: "auto",
          });
          return;
        }

        gsap.set(dropdownItems, {
          pointerEvents: "auto",
        });

        itemTweenRef.current = gsap.to(dropdownItems, {
          y: 0,
          opacity: 1,
          duration: navTextDuration,
          stagger: 0.02,
          ease,
          overwrite: true,
        });

        return;
      }

      switchTweenRef.current = gsap.delayedCall(0, () => {
        animateDropdownItemsOut(() => {
          if (activeDropdownIndexRef.current === null) return;

          setRenderedDropdownIndex(activeDropdownIndexRef.current);
        });
      });
    },
    [
      animateDropdownItemsOut,
      ease,
      getCurrentDropdownItems,
      killHideCall,
      killItemTween,
      killSwitchTween,
      menuItems,
      navTextDuration,
      reduceMotion,
      renderedDropdownIndex,
      setRenderedDropdownIndex,
      showWrapper,
    ]
  );

  const scheduleCloseDropdown = useCallback(() => {
    killHideCall();

    if (reduceMotion()) {
      if (isPointerInsideDropdownRef.current) return;
      closeDropdown();
      return;
    }

    hideCallRef.current = gsap.delayedCall(dropdownPointerDelay, () => {
      if (isPointerInsideDropdownRef.current) return;

      closeDropdown();
    });
  }, [closeDropdown, dropdownPointerDelay, killHideCall, reduceMotion]);

  const onHeaderMouseEnter = useCallback(() => {
    killHideCall();
  }, [killHideCall]);

  const onHeaderMouseLeave = useCallback(() => {
    killHideCall();
    killSwitchTween();

    activeDropdownIndexRef.current = null;
    isPointerInsideDropdownRef.current = false;

    setActiveChevronIndex(null);
    setNavVisualState(null);

    animateDropdownItemsOut(() => {
      setRenderedDropdownIndex(null);
      hideWrapper();
    });
  }, [
    animateDropdownItemsOut,
    hideWrapper,
    killHideCall,
    killSwitchTween,
    setNavVisualState,
    setRenderedDropdownIndex,
  ]);

  const onNavItemEnter = useCallback(
    (/** @type {number} */ index) => {
      const item = linkDataRef.current[index];

      if (!item) return;

      killHideCall();
      animateTextSwap(item, true);
      setNavVisualState(index);

      if (menuItems[index]?.isDropdown) {
        setActiveChevronIndex(index);
        activeDropdownIndexRef.current = index;
        openDropdownForIndex(index);
        return;
      }

      setActiveChevronIndex(null);
      activeDropdownIndexRef.current = null;
      closeDropdown();
    },
    [
      animateTextSwap,
      closeDropdown,
      killHideCall,
      menuItems,
      openDropdownForIndex,
      setNavVisualState,
    ]
  );

  const onNavItemLeave = useCallback(
    (/** @type {number} */ index) => {
      const item = linkDataRef.current[index];

      if (!item) return;

      animateTextSwap(item, false);

      if (menuItems[index]?.isDropdown) {
        return;
      }

      setNavVisualState(null);
    },
    [animateTextSwap, menuItems, setNavVisualState]
  );

  const onCtaHover = useCallback((/** @type {boolean} */ isEntering = true) => {
    const ctaElement = ctaRef.current;

    if (!ctaElement) return;

    const defaultText = ctaElement.querySelector("[data-default]");
    const hoverText = ctaElement.querySelector("[data-hover]");

    if (reduceMotion()) {
      gsap.set(ctaElement, {
        backgroundColor: isEntering
          ? ctaHoverBackground
          : ctaBackground,
        color: isEntering ? "#fff" : "#000",
      });
      gsap.set(defaultText, { yPercent: 0 });
      gsap.set(hoverText, { yPercent: 100 });
      return;
    }

    gsap
      .timeline({
        defaults: {
          duration: ctaDuration,
          ease,
          overwrite: true,
        },
      })
      .to(
        ctaElement,
        {
          backgroundColor: isEntering
            ? ctaHoverBackground
            : ctaBackground,
        },
        0
      )
      .to(defaultText, { yPercent: isEntering ? -100 : 0 }, 0)
      .to(hoverText, { yPercent: isEntering ? 0 : 100 }, 0);
  }, [ctaBackground, ctaDuration, ctaHoverBackground, ease, reduceMotion]);

  const onDropdownMouseEnter = useCallback(() => {
    isPointerInsideDropdownRef.current = true;
    killHideCall();
    showWrapper();
  }, [killHideCall, showWrapper]);

  const onDropdownMouseLeave = useCallback(() => {
    isPointerInsideDropdownRef.current = false;
    scheduleCloseDropdown();
  }, [scheduleCloseDropdown]);

  const onDropdownItemEnter = useCallback(
    (/** @type {number} */ index) => {
      animateTextSwap(dropdownTextDataRef.current[index], true);
    },
    [animateTextSwap]
  );

  const onDropdownItemLeave = useCallback(
    (/** @type {number} */ index) => {
      animateTextSwap(dropdownTextDataRef.current[index], false);
    },
    [animateTextSwap]
  );

  useLayoutEffect(() => {
    const context = gsap.context(() => {
      linkDataRef.current = navLinksRef.current.map((linkElement) => {
        if (!linkElement) return null;

        return {
          defaultText: linkElement.querySelector("[data-default]"),
          hoverText: linkElement.querySelector("[data-hover]"),
        };
      });

      linkDataRef.current.forEach((item) => {
        if (!item) return;

        gsap.set(item.defaultText, { yPercent: 0 });
        gsap.set(item.hoverText, { yPercent: 100 });
      });

      if (ctaRef.current) {
        const defaultText = ctaRef.current.querySelector("[data-default]");
        const hoverText = ctaRef.current.querySelector("[data-hover]");

        gsap.set(defaultText, { yPercent: 0 });
        gsap.set(hoverText, { yPercent: 100 });
      }

      hideWrapper();
    }, navWrapRef);

    return () => context.revert();
  }, [hideWrapper]);

  useLayoutEffect(() => {
    if (renderedDropdownIndex === null) return;

    initDropdownItemText();
    animateDropdownItemsIn();
  }, [animateDropdownItemsIn, initDropdownItemText, renderedDropdownIndex]);

  useEffect(() => {
    return () => {
      killHideCall();
      killSwitchTween();
      killItemTween();
    };
  }, [killHideCall, killItemTween, killSwitchTween]);

  const dropdownItems =
    renderedDropdownIndex !== null
      ? menuItems[renderedDropdownIndex]?.dropdown || []
      : [];

  return (
    <div
      ref={navWrapRef}
      onMouseEnter={onHeaderMouseEnter}
      onMouseLeave={onHeaderMouseLeave}
      className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-[0.55vw] bg-[#363737] text-[0.98vw]"
    >
      <div className="relative flex h-full w-full items-center gap-[1.95vw] p-[0.39vw] pl-[1.3vw]">
        <div className="flex h-full items-center gap-[1.95vw]">
          {menuItems.map((item, index) => {
            const isDropdownActive = activeChevronIndex === index;

            return (
              <a
                key={item.name}
                ref={(element) => {
                  navLinksRef.current[index] = element;
                }}
                href={item.href}
                className="relative flex items-center gap-[0.32vw] py-[0.65vw] text-[0.98vw] uppercase leading-none"
                onMouseEnter={() => onNavItemEnter(index)}
                onMouseLeave={() => onNavItemLeave(index)}
              >
                <div className="relative overflow-hidden">
                  <span data-default className="block">
                    {item.name}
                  </span>

                  <span
                    data-hover
                    className="absolute inset-0 flex items-center"
                  >
                    {item.name}
                  </span>
                </div>

                {item.isDropdown && (
                  <ChevronDown
                    className={`h-[1.3vw] w-[1.3vw] shrink-0 transition-transform duration-100 ease-out motion-reduce:rotate-0 motion-reduce:transition-none ${
                      isDropdownActive ? "-rotate-180" : "rotate-0"
                    }`}
                  />
                )}
              </a>
            );
          })}
        </div>

        <a
          ref={ctaRef}
          href={cta.href}
          className="relative overflow-hidden rounded-[0.26vw] bg-white px-[0.65vw] py-[0.65vw] text-[0.98vw] leading-none text-black"
          onMouseEnter={() => onCtaHover(true)}
          onMouseLeave={() => onCtaHover(false)}
        >
          <span data-default className="block">
            {cta.label}
          </span>

          <span
            data-hover
            className="absolute inset-0 flex items-center justify-center text-white"
          >
            {cta.label}
          </span>
        </a>

        <div
          ref={dropdownRef}
          onMouseEnter={onDropdownMouseEnter}
          onMouseLeave={onDropdownMouseLeave}
          className="absolute left-0 top-full h-fit w-full pt-[0.46vw]"
        >
          <div className="space-y-[0.52vw]">
            {dropdownItems.map((item, index) => (
              <div
                key={`${renderedDropdownIndex}-${item.title}`}
                ref={(element) => {
                  dropdownItemsRef.current[index] = element;
                }}
                className="link-btns"
              >
                <a
                  href={item.href}
                  onMouseEnter={() => onDropdownItemEnter(index)}
                  onMouseLeave={() => onDropdownItemLeave(index)}
                  className="flex items-center justify-between rounded-[0.55vw] bg-[#363737] p-[0.52vw] text-[0.98vw] text-white transition-all duration-300 hover:scale-[1.02] hover:bg-white hover:text-black! motion-reduce:scale-100 motion-reduce:bg-[#363737] motion-reduce:text-white! motion-reduce:transition-none"
                >
                  <div className="flex items-center gap-[1.95vw]">
                    <div className="size-[6.5vw] overflow-hidden rounded-[0.55vw]">
                      <img
                        src={item.img}
                        alt={item.title}
                        width={500}
                        height={500}
                        className="h-full w-full object-cover"
                      />
                    </div>

                    <div className="relative overflow-hidden uppercase leading-none">
                      <span data-default className="block">
                        {item.title}
                      </span>

                      <span
                        data-hover
                        className="absolute inset-0 flex items-center"
                      >
                        {item.title}
                      </span>
                    </div>
                  </div>

                  <ChevronRight className="mr-[2.6vw] h-[1.3vw] w-[1.3vw]" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
