"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import gsap from "gsap";
import { ChevronDown } from "lucide-react";

const FAQContext = createContext(null);
const FAQGroupContext = createContext(null);

const normalizeOpenItems = (items) => {
  if (Array.isArray(items)) {
    return items.map(String);
  }

  if (items === undefined || items === null || items === false) {
    return [];
  }

  return [String(items)];
};

const useFAQContext = () => {
  const context = useContext(FAQContext);

  if (!context) {
    throw new Error("FAQTitle and FAQContent must be used inside FAQWrapper.");
  }

  return context;
};

export function FAQGroup({
  children,
  allowMultiple = false,
  defaultOpenItems = [],
  value,
  onChange,
}) {
  const isControlled = value !== undefined;
  const normalizedValue = normalizeOpenItems(value);

  const [internalOpenItems, setInternalOpenItems] = useState(() =>
    normalizeOpenItems(defaultOpenItems)
  );

  const openItems = isControlled ? normalizedValue : internalOpenItems;

  const toggleItem = useCallback(
    (itemId) => {
      const normalizedItemId = String(itemId);

      const next = (() => {
        const isOpen = openItems.includes(normalizedItemId);

        if (allowMultiple) {
          return isOpen
            ? openItems.filter((id) => id !== normalizedItemId)
            : [...openItems, normalizedItemId];
        }

        return isOpen ? [] : [normalizedItemId];
      })();

      if (!isControlled) {
        setInternalOpenItems(next);
      }

      onChange?.(next);
    },
    [allowMultiple, isControlled, onChange, openItems]
  );

  const contextValue = useMemo(
    () => ({
      allowMultiple,
      openItems,
      toggleItem,
    }),
    [allowMultiple, openItems, toggleItem]
  );

  return (
    <FAQGroupContext.Provider value={contextValue}>
      {children}
    </FAQGroupContext.Provider>
  );
}

export function FAQWrapper({
  children,
  className = "",
  titleClassName = "",
  contentClassName = "",
  iconClassName = "",
  iconSize = 18,
  iconStrokeWidth = 2,
  duration = 0.45,
  defaultOpen = false,
  controlledOpen,
  onToggle,
  itemId,
}) {
  const group = useContext(FAQGroupContext);

  const generatedId = useId();
  const resolvedItemId = String(itemId ?? generatedId);

  const isStandaloneControlled = typeof controlledOpen === "boolean";
  const [internalOpen, setInternalOpen] = useState(defaultOpen);

  const isOpen = group
    ? group.openItems.includes(resolvedItemId)
    : isStandaloneControlled
      ? controlledOpen
      : internalOpen;

  const contentOuterRef = useRef(null);
  const contentInnerRef = useRef(null);

  const contentId = useId();
  const buttonId = useId();

  const handleToggle = () => {
    if (group) {
      group.toggleItem(resolvedItemId);
      onToggle?.(!isOpen);
      return;
    }

    if (isStandaloneControlled) {
      onToggle?.(!controlledOpen);
      return;
    }

    setInternalOpen((prev) => {
      const next = !prev;
      onToggle?.(next);
      return next;
    });
  };

  const handleWrapperClick = (event) => {
    const isInteractive = event.target.closest(
      "a, button, input, textarea, select"
    );

    if (isInteractive) return;

    handleToggle();
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      handleToggle();
    }
  };

  useEffect(() => {
    if (!contentOuterRef.current || !contentInnerRef.current) return;

    const outer = contentOuterRef.current;
    const inner = contentInnerRef.current;

    gsap.killTweensOf([outer, inner]);

    if (isOpen) {
      gsap.set(outer, {
        display: "block",
        overflow: "hidden",
      });

      gsap.fromTo(
        outer,
        { height: 0 },
        {
          height: inner.offsetHeight,
          duration,
          ease: "power3.out",
          onComplete: () => {
            gsap.set(outer, {
              height: "auto",
              overflow: "visible",
            });
          },
        }
      );
    } else {
      gsap.set(outer, {
        overflow: "hidden",
      });

      gsap.to(outer, {
        height: 0,
        duration,
        ease: "power3.out",
        onComplete: () => {
          gsap.set(outer, {
            display: "none",
          });
        },
      });
    }
  }, [isOpen, duration]);

  const value = {
    isOpen,
    contentOuterRef,
    contentInnerRef,
    contentId,
    buttonId,
    titleClassName,
    contentClassName,
    iconClassName,
    iconSize,
    iconStrokeWidth,
  };

  return (
    <FAQContext.Provider value={value}>
      <div
        className={`cursor-pointer ${className}`}
        role="button"
        tabIndex={0}
        aria-expanded={isOpen}
        aria-controls={contentId}
        id={buttonId}
        onClick={handleWrapperClick}
        onKeyDown={handleKeyDown}
      >
        {children}
      </div>
    </FAQContext.Provider>
  );
}

export function FAQTitle({
  children,
  className = "",
  showIcon = true,
  iconPosition = "right",
}) {
  const {
    isOpen,
    titleClassName,
    iconClassName,
    iconSize,
    iconStrokeWidth,
  } = useFAQContext();

  const icon = showIcon ? (
    <div className={`shrink-0 ${iconClassName}`}>
      <ChevronDown
        size={iconSize}
        strokeWidth={iconStrokeWidth}
        className={`transition-transform duration-300 ease-out ${
          isOpen ? "rotate-180" : "rotate-0"
        }`}
        aria-hidden="true"
      />
    </div>
  ) : null;

  return (
    <div
      className={`flex w-full items-start justify-between gap-6 ${titleClassName} ${className}`}
    >
      {iconPosition === "left" ? (
        <>
          {icon}
          <div className="flex-1">{children}</div>
        </>
      ) : (
        <>
          <div className="flex-1">{children}</div>
          {icon}
        </>
      )}
    </div>
  );
}

export function FAQContent({
  children,
  className = "",
  innerClassName = "",
}) {
  const {
    contentOuterRef,
    contentInnerRef,
    contentId,
    buttonId,
    contentClassName,
  } = useFAQContext();

  return (
    <div
      id={contentId}
      ref={contentOuterRef}
      role="region"
      aria-labelledby={buttonId}
      style={{
        height: 0,
        display: "none",
        overflow: "hidden",
      }}
      className={contentClassName}
    >
      <div ref={contentInnerRef} className={className}>
        <div className={innerClassName}>{children}</div>
      </div>
    </div>
  );
}

export const AnimatedFAQ = {
  Group: FAQGroup,
  Wrapper: FAQWrapper,
  Title: FAQTitle,
  Content: FAQContent,
};

export default AnimatedFAQ;