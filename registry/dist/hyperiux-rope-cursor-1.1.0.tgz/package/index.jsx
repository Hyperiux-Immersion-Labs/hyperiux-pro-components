"use client"

import React, { useEffect, useRef, useState } from'react'
import gsap from'gsap'
import { createSuspendedRaf } from './createSuspendedRaf'

export default function RopeCursor({
	ropeColor ='#bda985',
	ropeWidth = 2,
	ropeOpacity = 0.6,
	segmentLength = 0,
	segmentCount = 8,
}) {
	const svgRef = useRef(null)
	const pathRef = useRef(null)
	const ropeSegments = useRef([])
	const mousePosition = useRef({ x: null, y: null })
	const [isVisible, setIsVisible] = useState(false)
	const [isMobile, setIsMobile] = useState(false)

	useEffect(() => {
		const checkMobile = () => {
			setIsMobile(window.innerWidth < 1025)
		}

		checkMobile()
		window.addEventListener('resize', checkMobile)

		return () => window.removeEventListener('resize', checkMobile)
	}, [])

	useEffect(() => {
		if (isMobile) return

 let isInitialized = false

 const initializeRopeSegments = (startX, startY) => {
 ropeSegments.current = Array.from({ length: segmentCount }, () => ({
 x: startX,
 y: startY
 }))
 isInitialized = true
 setIsVisible(true)
 }

 const handleMouseMove = (event) => {
 mousePosition.current.x = event.clientX
 mousePosition.current.y = event.clientY

 if (!isInitialized && mousePosition.current.x !== null) {
 initializeRopeSegments(mousePosition.current.x, mousePosition.current.y)
 }
 }

 const updateLeadingSegment = (segments, targetX, targetY) => {
 gsap.to(segments[0], {
 x: targetX,
 y: targetY,
 duration: 0.05,
 ease:'power2.out'
 })
 }

 const updateFollowingSegments = (segments) => {
 for (let i = 1; i < segmentCount; i++) {
 const previousSegment = segments[i - 1]
 const currentSegment = segments[i]

 const deltaX = previousSegment.x - currentSegment.x
 const deltaY = previousSegment.y - currentSegment.y
 const distanceBetweenSegments = Math.sqrt(deltaX * deltaX + deltaY * deltaY)

 if (distanceBetweenSegments > segmentLength) {
 const angleToTarget = Math.atan2(deltaY, deltaX)
 const constrainedX = previousSegment.x - Math.cos(angleToTarget) * segmentLength
 const constrainedY = previousSegment.y - Math.sin(angleToTarget) * segmentLength

 gsap.to(currentSegment, {
 x: constrainedX,
 y: constrainedY,
 duration: 0.15 + i * 0.01,
 ease:'power2.out'
 })
 }
 }
 }

 const generateSmoothPath = (segments) => {
 let pathData = `M ${segments[0].x} ${segments[0].y}`

 for (let i = 1; i < segmentCount - 1; i++) {
 const controlPointX = (segments[i].x + segments[i + 1].x) / 2
 const controlPointY = (segments[i].y + segments[i + 1].y) / 2
 pathData += ` Q ${segments[i].x} ${segments[i].y} ${controlPointX} ${controlPointY}`
 }

 const lastSegment = segments[segmentCount - 1]
 pathData += ` L ${lastSegment.x} ${lastSegment.y}`

 return pathData
 }

 const loop = createSuspendedRaf({
 root: svgRef.current,
 onFrame: () => {
 const segments = ropeSegments.current
 const mouse = mousePosition.current

 if (!isInitialized || mouse.x === null) {
 return
 }

 updateLeadingSegment(segments, mouse.x, mouse.y)
 updateFollowingSegments(segments)

 if (pathRef.current) {
 pathRef.current.setAttribute('d', generateSmoothPath(segments))
 }
 },
 })

 window.addEventListener('mousemove', handleMouseMove)
 loop.start()

 return () => {
 window.removeEventListener('mousemove', handleMouseMove)
 loop.destroy()
 }
	}, [segmentCount, segmentLength, isMobile])

	if (isMobile) return null

	return (
 <>
 <svg
 ref={svgRef}
 className="w-full h-full absolute inset-0"
 style={{ opacity: isVisible ? 1 : 0 }}
 >
 <path
 ref={pathRef}
 fill="none"
 stroke={ropeColor}
 strokeWidth={ropeWidth}
 strokeLinecap="round"
 strokeLinejoin="round"
 opacity={ropeOpacity}
 />
 </svg>
 <div
   aria-live="polite"
   className="pointer-events-none fixed bottom-4 right-4 z-40 w-fit max-w-65 rounded-md border border-black/10 bg-white/10 backdrop-blur-sm p-3 text-center max-md:hidden"
 >
   <h2 className="text-sm leading-none text-[#111111]">
     The rope keeps swinging.
   </h2>
   <p className="mt-2 text-xs leading-5 text-black/65">
     Rope Cursor is a live trail of your cursor&apos;s movement. The
     motion is the entire effect, so it can&apos;t be swapped for a
     reduced motion alternative.
   </p>
 </div>
 </>
	)
}