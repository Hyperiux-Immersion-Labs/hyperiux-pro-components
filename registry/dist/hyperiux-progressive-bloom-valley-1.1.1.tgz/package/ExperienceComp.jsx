import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { useGLTF, useTexture } from "@react-three/drei";
import CameraRig from "./CameraRig";
import useValleyData from "./useValleyData";
import Flower from "./Flower";

// Tweak these values to change the look of the valley
const FLOWER_CONFIG = {
 flowerProbability: 1.0, // Controls how many flower patches appear (0.0 to 1.0)
 patchScale: 0.1, // How large the patches are (smaller number = larger patches)
 globalScale: .9, // Overall scale multiplier for all sprites
 minScale: 0.1, // Minimum random scale
 maxScaleRandom: 1.5, // Maximum additional random scale
 flowerThreshold: 0.1, // Threshold for spawning flower patches (> 0 defaults to grass)
 flowerDensity: 0.35, // Density of flowers within a patch
 grassScaleMult: 0.8, // Scale multiplier specifically for base grass
 flowerScaleMult: 1.2, // Scale multiplier specifically for flowers
 flowerYOffset: -0.02, // How much higher flowers sit above the base grass (negative embeds them in grass)
 colorTint: new THREE.Color(0.1, 0.1, 0.1), // brighten tint for"little light"
 rows: 300, // Number of rows along the path
 perRow: 360, // Number of sprites per row
 // Hover Interaction Config
 defaultFlowerBloom: 1.5, // Constant ambient brightness multiplier for flowers ONLY
 hoverGlowMultiplier: 5.0, // Max brightness multiplier for the bloom
 hoverMagneticStrength: 0.1, // How aggressively flowers are sucked towards the mouse (0 to 1+)
 hoverMagneticDirection: 1.0, // 1 is pull to cursor, -1 is repel away from cursor
 hoverZPull: .2 // How far flowers leap towards the camera lens in 3D
};

export default function Experience() {
 const gltf = useGLTF("https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/camera-path07.glb");
 const sprite = useTexture("https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/pool_summer.png");
 const terrainTex = useTexture("https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/terrain.png");

 const flowerSprite = useMemo(() => {
 const nextSprite = sprite.clone();
 nextSprite.colorSpace = THREE.SRGBColorSpace;
 nextSprite.minFilter = THREE.LinearFilter;
 nextSprite.magFilter = THREE.LinearFilter;
 nextSprite.needsUpdate = true;
 return nextSprite;
 }, [sprite]);

 useEffect(() => {
 return () => {
 flowerSprite.dispose();
 };
 }, [flowerSprite]);

 const cameraProps = useMemo(() => {
 const scene = gltf?.scene;
 if (!scene) return null;
 const cam = /** @type {import('three').PerspectiveCamera} */ (
 scene.getObjectByName("Camera") ||
 scene.getObjectByProperty("type","PerspectiveCamera") ||
 gltf.cameras?.[0]
 );
 if (!cam) return null;

 return {
 fov: cam.fov,
 near: cam.near,
 far: cam.far,
 rotation: [cam.rotation.x, cam.rotation.y, cam.rotation.z],
 };
 }, [gltf]);
 const { curve, flowers, pathOffset } = useValleyData(gltf, terrainTex, FLOWER_CONFIG);

 if (!curve || !flowers) return null;

 return (
 <>
 <CameraRig curve={curve} cameraProps={cameraProps} scrollConfig={{
 scrollIntensity: 0.1,
 autoSpeed: 0.00015,
 damping: 0.97,
 lerpSpeed: 0.03,
 loopPoint: 0.85,
 }} />
 {/* Copy 1: flowers at original position */}
 <Flower data={flowers} sprite={flowerSprite} config={FLOWER_CONFIG} />
 {/* Copy 2: same flowers shifted forward - fills the gap at the end */}
 <group position={/** @type {any} */ (pathOffset)}>
 <Flower data={flowers} sprite={flowerSprite} config={FLOWER_CONFIG} />
 </group>
 </>
 );
}

useGLTF.preload("https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/camera-path07.glb");
