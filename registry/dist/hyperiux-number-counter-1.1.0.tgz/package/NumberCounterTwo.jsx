'use client';

import { memo, useEffect, useRef } from'react';
import gsap from'gsap';
import { ScrollTrigger } from'gsap/dist/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const DIGITS = [...Array(10).keys()].concat(0);

/**
 * @typedef {'normal' | 'medium' | 'semibold' | 'bold'} CounterFontWeight
 */

const FONT_WEIGHTS = {
 normal:'font-normal',
 medium:'font-medium',
 semibold:'font-semibold',
 bold:'font-bold',
};

/**
 * @typedef {{
 *   digit: string,
 *   index: number,
 *   triggerRef: import('react').RefObject<HTMLElement | null>,
 *   reducedMotion?: boolean,
 * }} DigitScrollerProps
 */

/** @type {import('react').FC<DigitScrollerProps>} */
const DigitScroller = memo(({ digit, index, triggerRef, reducedMotion = false }) => {
 const digitRef = useRef(/** @type {HTMLDivElement | null} */ (null));

 useEffect(() => {
 if (reducedMotion || window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) return;
 if (!digitRef.current || !triggerRef.current) return;

 const digitIndex = parseInt(digit, 10);
 const ctx = gsap.context(() => {
 gsap.to(digitRef.current, {
 yPercent: -(digitIndex * 100),
 duration: 1.5,
 ease:'power2.inOut',
 delay: index * 0.1,
 scrollTrigger: {
 trigger: triggerRef.current,
 start:'top 85%',
 },
 });
 }, triggerRef);

 return () => ctx.revert();
 }, [digit, index, reducedMotion, triggerRef]);

 if (reducedMotion) {
 return (
 <span className="inline-flex h-[1em] w-[0.64em] items-center justify-center leading-none">
 {digit}
 </span>
 );
 }

 return (
 <div className="relative inline-flex h-[1em] w-[0.64em] overflow-hidden align-baseline leading-none">
 <div ref={digitRef} className="flex flex-col will-change-transform">
 {DIGITS.map((num, digitIndex) => (
 <span
 key={`${num}-${digitIndex}`}
 className="flex h-[1em] items-center justify-center leading-none"
 >
 {num}
 </span>
 ))}
 </div>
 </div>
 );
});

DigitScroller.displayName ='DigitScroller';

/**
 * @typedef {Object} NumberCounterTwoProps
 * @property {string} [value]
 * @property {string} [textSize]
 * @property {string} [color]
 * @property {CounterFontWeight} [fontWeight]
 * @property {boolean} [reducedMotion]
 */

/** @param {NumberCounterTwoProps} props */
const NumberCounterTwo = ({
 value ='0',
 textSize ='text-[8vw] max-[1025px]:text-[7vw] max-md:text-[12vw]',
 color ='#111111',
 fontWeight ='normal',
 reducedMotion = false, }) => {
 const containerRef = useRef(/** @type {HTMLDivElement | null} */ (null));
 const cleanValue = value.replace('+','');

 return (
 <div ref={containerRef} className="flex items-end gap-[2vw] w-fit max-[1025px]:gap-0">
 <div
 className={`flex items-end font-display leading-none ${textSize} ${FONT_WEIGHTS[/** @type {CounterFontWeight} */ (fontWeight)] ||'font-normal'}`}
 style={{ color }}
 >
 {cleanValue.split('').map((digit, index) => (
 <DigitScroller
 key={`${digit}-${index}`}
 digit={digit}
 index={index}
 triggerRef={containerRef}
 reducedMotion={reducedMotion}
 />
 ))}

 {value.includes('+') && (
 <span className="inline-flex h-[1em] items-center justify-center leading-none">
 +
 </span>
 )}
 </div>
 </div>
 );
};

export default NumberCounterTwo;
