// Built using Hyperiux Vault: https://vault.hyperiux.com

'use client'

import { useRef, useEffect, useMemo, useState } from 'react'
import { Canvas, useFrame, useThree, useLoader } from '@react-three/fiber'
import { useGLTF } from '@react-three/drei'
import * as THREE from 'three'
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js'
import { createVisibilityGate } from './createSuspendedRaf'

const BUTTERFLY_LIFETIME = 2
const FADE_DURATION = 0.5
const MAX_BUTTERFLIES = 200
const SPAWN_THROTTLE = 120

function usePrefersReducedMotion() {
	const [prefersReducedMotion, setPrefersReducedMotion] = useState(false)

	useEffect(() => {
		const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
		const update = () => setPrefersReducedMotion(mediaQuery.matches)
		update()
		mediaQuery.addEventListener('change', update)
		return () => mediaQuery.removeEventListener('change', update)
	}, [])

	return prefersReducedMotion
}

function ButterflyPool({ matcapMaterial, gltfScene, gltfAnimations }) {
	const poolRef = useRef([])
	const activeCountRef = useRef(0)
	const lastSpawnTime = useRef(0)
	const { size } = useThree()

	// Initialize pool of butterfly instances
	const { poolGroup, pool } = useMemo(() => {
		const group = new THREE.Group()
		const pool = []
		for (let i = 0; i < MAX_BUTTERFLIES; i++) {
			const clone = SkeletonUtils.clone(gltfScene)
			// Create unique material instance for each butterfly to allow individual opacity
			const instanceMaterial = matcapMaterial.clone()
			instanceMaterial.transparent = true
			instanceMaterial.opacity = 1
			clone.traverse((child) => {
				if (child.isMesh || child.isSkinnedMesh) {
					child.material = instanceMaterial
				}
			})
			clone.scale.setScalar(0.0012)
			clone.visible = false
			clone.userData = {
				active: false,
				direction: new THREE.Vector3(),
				createdAt: 0,
				animationOffset: 0,
				initialRotation: new THREE.Euler(),
				material: instanceMaterial
			}
			// Create animation mixer for this instance
			const mixer = new THREE.AnimationMixer(clone)
			if (gltfAnimations.length > 0) {
				const action = mixer.clipAction(gltfAnimations[0])
				action.play()
				clone.userData.mixer = mixer
				clone.userData.action = action
			}
			group.add(clone)
			pool.push(clone)
		}
		return { poolGroup: group, pool }
	}, [gltfScene, gltfAnimations, matcapMaterial])

	useEffect(() => {
		poolRef.current = pool
		return () => {
			poolRef.current = []
		}
	}, [pool])

	useFrame((state, delta) => {
		const now = state.clock.elapsedTime
		// Update all active butterflies
		for (let i = 0; i < MAX_BUTTERFLIES; i++) {
			const butterfly = poolRef.current[i]
			if (!butterfly) continue
			const data = butterfly.userData
			if (!data.active) continue
			const age = now - data.createdAt
			const fadeStartTime = BUTTERFLY_LIFETIME - FADE_DURATION
			// Handle fade out
			if (age > fadeStartTime) {
				const fadeProgress = (age - fadeStartTime) / FADE_DURATION
				const opacity = Math.max(0, 1 - fadeProgress)
				data.material.opacity = opacity
				// Slow down animation during fade
				if (data.action) {
					data.action.timeScale = (1.6 + Math.random() * 0.8) * opacity
				}
			}
			// Check lifetime (after fade completes)
			if (age > BUTTERFLY_LIFETIME) {
				butterfly.visible = false
				data.active = false
				data.material.opacity = 1 // Reset for next use
				activeCountRef.current--
				continue
			}
			// Update position
			butterfly.position.x += data.direction.x * delta * 2
			butterfly.position.y += data.direction.y * delta * 2
			butterfly.position.z += data.direction.z * delta * 0.5
			butterfly.rotation.x = data.initialRotation.x + Math.sin(now * 3 + butterfly.position.x) * 0.1
			butterfly.rotation.y = data.initialRotation.y
			butterfly.rotation.z = data.initialRotation.z
			// Update animation
			if (data.mixer) {
				data.mixer.update(delta)
			}
		}
	})

	useEffect(() => {
		const handleMouseMove = (e) => {
			const now = Date.now()
			if (now - lastSpawnTime.current < SPAWN_THROTTLE) return
			lastSpawnTime.current = now

			const x = (e.clientX / size.width) * 10 - 5
			const y = -(e.clientY / size.height) * 6 + 3
			const count = 3 + Math.floor(Math.random() * 3)
			const createdAt = performance.now() / 1000

			// Find inactive butterflies and activate them
			let spawned = 0
			for (let i = 0; i < MAX_BUTTERFLIES && spawned < count; i++) {
				const butterfly = poolRef.current[i]
				if (!butterfly) continue
				const data = butterfly.userData
				if (!data.active) {
					const angle = Math.random() * Math.PI * 2
					butterfly.position.set(
						x + (Math.random() - 0.5) * 1.5,
						y + (Math.random() - 0.5) * 1.5,
						(Math.random() - 0.5) * 0.5
					)
					data.direction.set(
						Math.cos(angle) * 0.75,
						0.3 + Math.random() * 0.5,
						(Math.random() - 0.5) * 0.3
					)
					// Set random initial rotation for variety
					data.initialRotation.set(
						(Math.random() - 0.5) * Math.PI * 0.3,
						Math.random() * Math.PI * 2,
						(Math.random() - 0.5) * Math.PI * 0.2
					)
					butterfly.rotation.copy(data.initialRotation)
					data.createdAt = createdAt
					data.active = true
					data.material.opacity = 1
					butterfly.visible = true
					if (data.action) {
						data.action.timeScale = 1.6 + Math.random() * 0.8
						data.action.time = Math.random() * 2
					}
					activeCountRef.current++
					spawned++
				}
			}
		}

		window.addEventListener('mousemove', handleMouseMove)
		return () => window.removeEventListener('mousemove', handleMouseMove)
	}, [size])

	return <primitive object={poolGroup} />
}

function ButterflyTrail() {
	const matcapTexture = useLoader(THREE.TextureLoader, 'https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/matcap-white.webp')
	const { scene: gltfScene, animations: gltfAnimations } = useGLTF('https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/butterfly3.glb')

	const matcapMaterial = useMemo(() => {
		return new THREE.MeshMatcapMaterial({
			matcap: matcapTexture,
			side: THREE.DoubleSide
		})
	}, [matcapTexture])

	return (
		<ButterflyPool matcapMaterial={matcapMaterial} gltfScene={gltfScene} gltfAnimations={gltfAnimations} />
	)
}

useGLTF.preload('https://pub-8abee449136941f5b0a1cd2c014534e9.r2.dev/butterfly3.glb')

export default function ButterflyTrailCursor() {
	const rootRef = useRef(null)
	const [frameloop, setFrameloop] = useState('always')
	const prefersReducedMotion = usePrefersReducedMotion()

	useEffect(() => {
		const gate = createVisibilityGate({
			root: rootRef,
			onChange: (active) => setFrameloop(active ? 'always' : 'never'),
		})
		setFrameloop(gate.isActive ? 'always' : 'never')
		return () => gate.destroy()
	}, [])

	return (
		<div
			ref={rootRef}
			className="w-full h-screen relative bg-[#EAEAE9]"
			style={{ backgroundColor: '#EAEAE9' }}
		>
			<Canvas
				style={{ backgroundColor: '#EAEAE9' }}
				camera={{ position: [0, 0, 5], fov: 75 }}
				gl={{ antialias: false, powerPreference: 'high-performance', alpha: true }}
				onCreated={({ gl }) => {
					gl.setClearColor(new THREE.Color('#EAEAE9'), 1)
				}}
				dpr={[1, 1]}
				performance={{ min: 0.5 }}
				frameloop={frameloop}
			>
				<color attach="background" args={['#EAEAE9']} />
				<ButterflyTrail />
			</Canvas>

			{prefersReducedMotion && (
				<div
					aria-live="polite"
					className="pointer-events-none fixed bottom-4 right-4 z-40 w-fit max-w-65 rounded-md border border-black/10 bg-white/10 backdrop-blur-sm p-3 text-center max-md:hidden"
				>
					<h2 className="text-sm leading-none text-[#111111]">
						The butterflies keep drifting.
					</h2>
					<p className="mt-2 text-xs leading-5 text-black/65">
						These butterflies are animated purely by cursor movement. Pausing
						that motion would remove the effect, so reduced motion isn&apos;t
						supported here.
					</p>
				</div>
			)}
		</div>
	)
}
