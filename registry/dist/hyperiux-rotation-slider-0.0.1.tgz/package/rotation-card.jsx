"use client";
import React, { forwardRef } from "react";

const RotationCard = forwardRef(({ src, index, total }, ref) => {
  return (
    <div
      ref={ref}
      className="absolute w-[38vw] h-[45vh] max-sm:w-[75vw] max-sm:h-[35vh] origin-right overflow-hidden opacity-0"
      style={{
        transformStyle: "preserve-3d",
        zIndex: total - index,
      }}
    >
      <div
        className="w-full h-full relative"
        style={{
          transformStyle: "preserve-3d",
        }}
      >
        <img
          src={src}
          alt="slider"
          className="object-cover absolute inset-0"
        />
      </div>
    </div>
  );
});

export default RotationCard;