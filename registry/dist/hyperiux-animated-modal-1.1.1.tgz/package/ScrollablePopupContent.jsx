"use client";



/**
 * @typedef {Object} PopupSection
 * @property {string} [heading]
 * @property {string} [paragraph]
 * @property {string[]} [list]
 */

/**
 * @typedef {Object} ScrollablePopupContentProps
 * @property {string} [title]
 * @property {string} [subtitle]
 * @property {PopupSection[]} [sections]
 * @property {string} [className]
 */

/** @param {ScrollablePopupContentProps} props */
const ScrollablePopupContent = ({
    title = "Popup Title",
    subtitle = "",
    sections = [],
    className = "",
}) => {
    return (
        <div
            className={`mx-auto w-[min(92vw,960px)] max-h-[82vh] overflow-hidden rounded-[1.5vw] bg-white text-[#111111] shadow-[0_20px_80px_rgba(0,0,0,0.18)] max-[1025px]:max-h-[84vh] max-[1025px]:w-[min(94vw,960px)] max-[1025px]:rounded-[2.4vw] max-md:max-h-[86vh] max-md:w-[94vw] max-md:rounded-[4vw] ${className}`}
        >
            <div className="h-full max-h-[82vh] overflow-y-auto p-[2.4vw] scrollbar-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-black/20 max-[1025px]:max-h-[84vh] max-[1025px]:p-[4vw] max-md:max-h-[86vh] max-md:px-[5vw] max-md:py-[6vw]">
                <div className="border-b border-black/8 pb-[1.6vw]">
                    <p
                        className="mb-[0.6vw] text-[0.85vw] uppercase tracking-[0.08em] opacity-55 font-semibold max-[1025px]:mb-[1vw] max-[1025px]:text-[1.6vw] max-md:mb-[1.8vw] max-md:text-[3vw]"
                    >
                        Overview
                    </p>
                    <h2
                        className="mb-[1vw] text-[2.2vw] leading-none font-semibold max-[1025px]:mb-[1.6vw] max-[1025px]:text-[4.6vw] max-md:mb-[2.5vw] max-md:text-[7vw]"
                    >
                        {title}
                    </h2>
                    {subtitle ? (
                        <p className="w-[80%] text-[1vw] leading-[1.7] opacity-80 max-[1025px]:w-full max-[1025px]:text-[1.9vw] max-md:text-[3.6vw] max-md:leading-[1.7]">
                            {subtitle}
                        </p>
                    ) : null}
                </div>

                <div className="flex flex-col gap-[2vw] pt-[1.8vw] max-[1025px]:gap-[3.2vw] max-[1025px]:pt-[3vw] max-md:gap-[5vw] max-md:pt-[5vw]">
                    {sections.map((section, index) => (
                        <div key={index} className="flex flex-col gap-[0.9vw] max-[1025px]:gap-[1.4vw] max-md:gap-[2.4vw]">
                            {section.heading ? (
                                <h3
                                    className="text-[1.25vw] leading-[1.2] font-semibold max-[1025px]:text-[2.4vw] max-md:text-[4.4vw]"
                                >
                                    {section.heading}
                                </h3>
                            ) : null}

                            {section.paragraph ? (
                                <p className="text-[1vw] leading-[1.8] opacity-80 max-[1025px]:text-[1.9vw] max-md:text-[3.6vw] max-md:leading-[1.8]">
                                    {section.paragraph}
                                </p>
                            ) : null}

                            {section.list?.length ? (
                                <ul className="flex flex-col gap-[0.6vw] pl-[1.2vw] max-[1025px]:gap-[1vw] max-[1025px]:pl-[2.2vw] max-md:gap-[1.8vw] max-md:pl-[4vw] [&>li]:text-[1vw] [&>li]:leading-[1.7] [&>li]:opacity-80 max-[1025px]:[&>li]:text-[1.85vw] max-md:[&>li]:text-[3.4vw] max-md:[&>li]:leading-[1.7]">
                                    {section.list.map((item, itemIndex) => (
                                        <li key={itemIndex}>{item}</li>
                                    ))}
                                </ul>
                            ) : null}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ScrollablePopupContent;
