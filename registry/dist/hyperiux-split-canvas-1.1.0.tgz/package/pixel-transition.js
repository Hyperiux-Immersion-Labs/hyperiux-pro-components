export const PixelTransitionVertex = `
 varying vec2 vUv;

 void main() {
 vUv = uv;
 gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
 }
`;

export const PixelTransitionFragment = `
 uniform sampler2D u_texture1;
 uniform sampler2D u_texture2;
 uniform float u_progress;
 uniform float u_numSlices;
 uniform vec2 u_resolution;
 uniform float u_gridSize;
 uniform float u_reducedMotion;

 varying vec2 vUv;

 vec2 getPixelatedUv(vec2 uv, vec2 resolution, float gridSize) {
 vec2 gridCount = max(floor(resolution / gridSize), vec2(1.0));
 vec2 cellSize = resolution / gridCount;
 vec2 pixelPos = uv * resolution;
 vec2 cellIndex = floor(pixelPos / cellSize);
 vec2 cellCenter = (cellIndex + 0.5) * cellSize;

 return cellCenter / resolution;
 }

 // Draw grid lines only (transparent background)
 float drawGridLines(vec2 uv, vec2 resolution, float gridSize) {
 vec2 gridCount = max(floor(resolution / gridSize), vec2(1.0));
 vec2 cellSize = resolution / gridCount;
 vec2 pixelPos = uv * resolution;
 float lineWidth = 1.0;

 // Vertical and horizontal lines
 float vLine = step(mod(pixelPos.x, cellSize.x), lineWidth);
 float hLine = step(mod(pixelPos.y, cellSize.y), lineWidth);

 return max(vLine, hLine);
 }

 void main() {
 vec2 uv = vUv;
 vec2 pixelatedUv = getPixelatedUv(uv, u_resolution, u_gridSize);

 // Grid lines (just the lines, transparent elsewhere)
 float gridLine = drawGridLines(uv, u_resolution, u_gridSize);
 vec4 gridColor = vec4(0.0, 0.0, 0.0, gridLine * 0.15); // Semi-transparent black lines

 vec4 texColor;

 if (u_reducedMotion > 0.5) {
 // Reduced motion: plain crossfade, no pixelation/slice-blind motion.
 vec4 tex1 = texture2D(u_texture1, uv);
 vec4 tex2 = texture2D(u_texture2, uv);
 texColor = mix(tex1, tex2, u_progress);
 } else {
 // Number of horizontal slices (blinds)
 float slices = u_numSlices;
 float sliceIndex = floor(uv.y * slices);
 float sliceNorm = sliceIndex / slices;
 float sliceHeight = 1.0 / slices;
 float posInSlice = fract(uv.y * slices);

 // Bottom slices transition first
 float sliceDelay = sliceNorm * 0.6;
 float sliceProgress = smoothstep(sliceDelay, sliceDelay + 0.4, u_progress);

 // Blind collapse effect
 float blindScale = 1.0 - sliceProgress;
 float visibleThreshold = 1.0 - blindScale;

 // Determine which texture to show based on blind position
 if (posInSlice < visibleThreshold) {
 // Collapsed part - show texture2
 texColor = texture2D(u_texture2, pixelatedUv);
 } else {
 // Visible part - show texture1 with slide offset
 vec2 adjustedUV = uv;
 float slideOffset = visibleThreshold * sliceHeight;
 adjustedUV.y = clamp(uv.y - slideOffset, 0.0, 1.0);
 texColor = texture2D(u_texture1, getPixelatedUv(adjustedUV, u_resolution, u_gridSize));
 }
 }

 // Composite: transparent background + grid lines + image
 // Start with grid on transparent background
 vec4 result = gridColor;

 // Blend image on top (image alpha determines visibility)
 result = vec4(
 mix(result.rgb, texColor.rgb, texColor.a),
 max(result.a, texColor.a)
 );

 gl_FragColor = result;
 }
`;
