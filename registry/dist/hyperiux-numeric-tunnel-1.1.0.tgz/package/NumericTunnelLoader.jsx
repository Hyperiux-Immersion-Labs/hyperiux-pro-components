'use client'

import React, { useEffect, useMemo, useRef, useState } from'react'
import { Canvas, createPortal, useFrame, useThree } from'@react-three/fiber'
import { Text, useFBO } from'@react-three/drei'
import * as THREE from'three'
import gsap from'gsap'

// ---- CONFIGURATION ----
const TUNNEL_CONFIG = {
 ringCount: 5,
 countPerRing: 10,
 ringRadius: 2,
 ringStartScale: 0.01,
 ringEndScale: 8,
 ringRotateSpeed: 1.2,
 ringFadeInPhase: 0.1,
 ringFullVisiblePhase: 0.7,
 ringFadeOutPhase: 0.9,
 ringFontSize: 0.5,
 ringLetterSpacing: -0.05,
 textColor:'#ffffff',
 crossfadeDuration: 2,
 canvasFadeDuration: 500,
 tunnelFadeOutDelay: 5,
 loaderTickInterval: 40,
 loaderStartDelay: 1200,
 backgroundColor:'#000000'
}

/**
 * @typedef {import('react').MutableRefObject<number>} PhaseRef
 */

/**
 * @param {{
 *   index: number,
 *   loaderValue: number,
 *   tunnelPhaseRef: PhaseRef,
 * }} props
 */
function TunnelRing({ index, loaderValue, tunnelPhaseRef }) {
 const groupRef = useRef(/** @type {THREE.Group | null} */ (null))
 const ringContentRef = useRef(/** @type {THREE.Group | null} */ (null))
 const textMaterialRef = useRef(/** @type {THREE.MeshBasicMaterial | null} */ (null))
 const direction = index % 2 === 0 ? 1 : -1
 const reduceMotionRef = useRef(
 typeof window !== 'undefined' &&
 (window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches ?? false)
 )

 const textMaterial = useMemo(
 () =>
 new THREE.MeshBasicMaterial({
 color: new THREE.Color(TUNNEL_CONFIG.textColor),
 transparent: true,
 opacity: 0,
 depthWrite: false,
 }),
 []
 )

 useEffect(() => {
 textMaterialRef.current = textMaterial
 return () => {
 textMaterialRef.current = null
 textMaterial.dispose()
 }
 }, [textMaterial])

 useEffect(() => {
 const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)')
 if (!mq) return undefined
 /** @param {MediaQueryListEvent} event */
 const onChange = (event) => {
 reduceMotionRef.current = event.matches
 }
 reduceMotionRef.current = mq.matches
 mq.addEventListener?.('change', onChange)
 return () => mq.removeEventListener?.('change', onChange)
 }, [])

 useFrame(
 /**
  * @param {import('@react-three/fiber').RootState} state
  * @param {number} delta
  */
 (state, delta) => {
 if (!groupRef.current || !ringContentRef.current) return
 const material = textMaterialRef.current
 if (!material) return

 const time = state.clock.getElapsedTime()
 const speed = 0.25

 // Instead of adding index mapped offset, subtract it to delay spawn.
 // This makes rings wait their turn to start from the center.
 const rawPhase = time * speed - index / TUNNEL_CONFIG.ringCount

 if (rawPhase < 0) {
 groupRef.current.scale.set(0.001, 0.001, 0.001)
 material.opacity = 0
 } else {
 const phase = rawPhase % 1

 // Scale calculation
 const scale =
 Math.pow(phase, 3) * TUNNEL_CONFIG.ringEndScale +
 TUNNEL_CONFIG.ringStartScale

 groupRef.current.scale.set(scale, scale, scale)

 // Opacity calculation by phase
 let opacity = 0
 if (phase < TUNNEL_CONFIG.ringFadeInPhase)
 opacity = phase / TUNNEL_CONFIG.ringFadeInPhase
 else if (phase <= TUNNEL_CONFIG.ringFullVisiblePhase)
 opacity = 1
 else if (phase <= TUNNEL_CONFIG.ringFadeOutPhase)
 opacity = 1 - (phase - TUNNEL_CONFIG.ringFullVisiblePhase) / (TUNNEL_CONFIG.ringFadeOutPhase - TUNNEL_CONFIG.ringFullVisiblePhase)
 else opacity = 0

 // Fade out rings as tunnelPhase progresses
 material.opacity = opacity * (1 - tunnelPhaseRef.current)
 }

 // Reduced-motion: keep counter, skip ring rotation.
 if (!reduceMotionRef.current) {
 ringContentRef.current.rotation.z += delta * TUNNEL_CONFIG.ringRotateSpeed * direction
 }
 })

 return (
 <group ref={groupRef} position={[0, 0, -index * 0.01]}>
 <group ref={ringContentRef}>
 {Array.from({ length: TUNNEL_CONFIG.countPerRing }).map((_, i) => {
 const angle = (i / TUNNEL_CONFIG.countPerRing) * Math.PI * 2
 const x = Math.cos(angle) * TUNNEL_CONFIG.ringRadius
 const y = Math.sin(angle) * TUNNEL_CONFIG.ringRadius

 return (
 <Text
 key={i}
 position={[x, y, 0]}
 rotation={[0, 0, angle - Math.PI / 2]}
 fontSize={TUNNEL_CONFIG.ringFontSize}
 anchorX="center"
 anchorY="middle"
 letterSpacing={TUNNEL_CONFIG.ringLetterSpacing}
 material={textMaterial}
 >
 {loaderValue.toString().padStart(2,'0')}
 </Text>
 )
 })}
 </group>
 </group>
 )
}

/**
 * @param {{
 *   loaderValue: number,
 *   tunnelPhaseRef: PhaseRef,
 * }} props
 */
function TunnelScene({ loaderValue, tunnelPhaseRef }) {
 return (
 <>
 <color attach="background" args={[TUNNEL_CONFIG.backgroundColor]} />
 {Array.from({ length: TUNNEL_CONFIG.ringCount }).map((_, i) => (
 <TunnelRing key={i} index={i} loaderValue={loaderValue} tunnelPhaseRef={tunnelPhaseRef} />
 ))}
 </>
 )
}

/**
 * @param {{
 *   children?: import('react').ReactNode,
 *   active: boolean,
 *   tunnelPhaseRef: PhaseRef,
 * }} props
 */
function WholeSceneEffect({ children, active, tunnelPhaseRef }) {
 const { gl, camera, size, viewport } = useThree()
 const portalScene = useMemo(() => new THREE.Scene(), [])
 const fbo = useFBO(size.width, size.height, /** @type {any} */ ({ samples: 0, depth: false }))
 const materialRef = useRef(/** @type {THREE.ShaderMaterial | null} */ (null))
 const reduceMotionRef = useRef(
 typeof window !== 'undefined' &&
 (window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches ?? false)
 )

 useEffect(() => {
 const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)')
 if (!mq) return undefined
 /** @param {MediaQueryListEvent} event */
 const onChange = (event) => {
 reduceMotionRef.current = event.matches
 }
 reduceMotionRef.current = mq.matches
 mq.addEventListener?.('change', onChange)
 return () => mq.removeEventListener?.('change', onChange)
 }, [])

 // Pass tunnelPhase as a uniform for smooth shader transition
 const material = useMemo(() => {
 return new THREE.ShaderMaterial({
 depthTest: false,
 depthWrite: false,
 transparent: true,
 uniforms: {
 tDiffuse: { value: fbo.texture },
 uTime: { value: 0 },
 uStrength: { value: 10.5 },
 uResolution: { value: new THREE.Vector2(size.width, size.height) },
 uTunnelPhase: { value: 0 },
 },
 vertexShader: /* glsl */ `
 varying vec2 vUv;
 varying float vDeform;
 uniform float uTime;
 uniform float uStrength;
 uniform float uTunnelPhase;
 void main() {
 vUv = uv;
 vec3 pos = position;

 float isLeft = step(0.0, -pos.x);
 float deform = isLeft * (1.0 - (pos.x + 0.5) * 2.0);

 deform *= sin(uTime * 2.4 + pos.y * 7.0 + pos.x * 5.2) * 0.23 * uStrength;
 pos.x += deform * 0.28 * uTunnelPhase;
 pos.z += isLeft * sin(uTime * 1.7 + pos.x * 10.0) * 0.15 * uStrength * uTunnelPhase;

 vDeform = deform * uTunnelPhase;
 gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
 }
 `,
 fragmentShader: /* glsl */ `
 varying vec2 vUv;
 varying float vDeform;
 uniform sampler2D tDiffuse;
 uniform float uTunnelPhase;
 uniform float uTime;
 void main() {
 float aberrationAmount = vDeform * 0.04;
 vec2 offset = vec2(aberrationAmount, 0.0);

 vec4 cr = texture2D(tDiffuse, vUv + offset);
 vec4 cg = texture2D(tDiffuse, vUv);
 vec4 cb = texture2D(tDiffuse, vUv - offset);

 float alpha = max(cr.a, max(cg.a, cb.a));
 vec4 baseColor = vec4(cr.r, cg.g, cb.b, alpha);

 vec3 shiftColor = vec3(
 0.5 + 0.5 * sin(uTime * 3.0 + vUv.y * 10.0),
 0.5 + 0.5 * sin(uTime * 2.0 + vUv.x * 10.0 + 2.0),
 0.5 + 0.5 * sin(uTime * 4.0 + vUv.y * 5.0 + 4.0)
 );

 float shiftIntensity = abs(vDeform) * .2;

 vec3 finalColor = mix(
 baseColor.rgb,
 baseColor.rgb * shiftColor * 2.5 + shiftColor * alpha * 0.3,
 clamp(shiftIntensity, 0.0, 1.0)
 );

 gl_FragColor = vec4(finalColor, alpha * uTunnelPhase);
 }
 `,
 })
 }, [fbo.texture, size.width, size.height])

 useEffect(() => {
 materialRef.current = material
 materialRef.current.uniforms.uResolution.value.set(size.width, size.height)
 }, [material, size.width, size.height])

 useEffect(() => {
 return () => {
 materialRef.current = null
 material.dispose()
 }
 }, [material])

 useFrame(
 /**
  * @param {import('@react-three/fiber').RootState} state
  * @param {number} delta
  */
 (state, delta) => {
 // always render tunnel pass, then crossfade
 gl.setRenderTarget(fbo)
 gl.clear(true, true, true)
 gl.render(portalScene, camera)
 gl.setRenderTarget(null)

 const shaderMaterial = materialRef.current
 if (!shaderMaterial) return

 shaderMaterial.uniforms.uTime.value = state.clock.getElapsedTime()
 shaderMaterial.uniforms.uTunnelPhase.value = tunnelPhaseRef.current
 // Reduced-motion: keep the crossfade, skip the warp/distortion strength ramp.
 shaderMaterial.uniforms.uStrength.value = reduceMotionRef.current
 ? 0
 : THREE.MathUtils.lerp(5.5, 1, tunnelPhaseRef.current)
 })

 return (
 <>
 {createPortal(children, portalScene)}
 <group>{children}</group>
 <mesh
 scale={[viewport.width, viewport.height, 1]}
 position={[0, 0, 0]}
 renderOrder={10}
 >
 <planeGeometry args={[1, 1, 48, 48]} />
 <primitive object={material} attach="material" />
 </mesh>
 </>
 )
}

/**
 * @param {{
 *   loaderValue: number,
 *   onComplete?: () => void,
 * }} props
 */
function NumericTunnelCanvas({ loaderValue, onComplete }) {
 const [effectActive, setEffectActive] = useState(false)
 // Remove useState for canvasOpacity, use a ref instead
 const canvasRef = useRef(/** @type {HTMLDivElement | null} */ (null))
 const didScheduleRef = useRef(false)
 const tunnelPhaseRef = useRef(0)

 useEffect(() => {
 /** @type {number | undefined} */
 let anim
 /** @type {ReturnType<typeof setTimeout> | undefined} */
 let fadeTimeout
 if (loaderValue >= 100 && !didScheduleRef.current) {
 didScheduleRef.current = true
 setEffectActive(true)
 let t = 0
 const duration = TUNNEL_CONFIG.crossfadeDuration
 const step = () => {
 t += 1 / 60
 tunnelPhaseRef.current = Math.min(t / duration, 1)
 if (t < duration) {
 anim = requestAnimationFrame(step)
 } else {
 fadeTimeout = setTimeout(() => {
 if (onComplete) {
 onComplete()
 return
 }
 // Animate opacity to 0 using GSAP; remove setCanvasOpacity, use ref
 if (canvasRef.current) {
 gsap.to(canvasRef.current, {
 opacity: 0,
 duration: TUNNEL_CONFIG.canvasFadeDuration / 1000,
 ease:"power3.inOut",
 })
 }
 }, TUNNEL_CONFIG.tunnelFadeOutDelay)
 }
 }
 requestAnimationFrame(step)
 }
 return () => {
 if (anim !== undefined) cancelAnimationFrame(anim)
 clearTimeout(fadeTimeout)
 }
 }, [loaderValue, onComplete])

 return (
 <div
 ref={canvasRef}
 className="h-full bg-black w-full"
 >
 <Canvas
 dpr={1}
 orthographic
 camera={{ zoom: 100, position: [0, 0, 10] }}
 gl={{ powerPreference:'high-performance' }}
 >
 <color attach="background" args={[TUNNEL_CONFIG.backgroundColor]} />
 <WholeSceneEffect active={effectActive} tunnelPhaseRef={tunnelPhaseRef}>
 <TunnelScene loaderValue={loaderValue} tunnelPhaseRef={tunnelPhaseRef} />
 </WholeSceneEffect>
 </Canvas>
 </div>
 )
}

/**
 * @param {{
 *   children?: import('react').ReactNode,
 *   onComplete?: () => void,
 * }} props
 */
export function NumericTunnelLoader({ children, onComplete }) {
 const [loaderValue, setLoaderValue] = useState(0)
 const [isComplete, setIsComplete] = useState(false)

 useEffect(() => {
 /** @type {ReturnType<typeof setInterval> | undefined} */
 let interval;
 const timeout = setTimeout(() => {
 interval = setInterval(() => {
 setLoaderValue((prev) => (prev >= 100 ? 100 : prev + 1))
 }, TUNNEL_CONFIG.loaderTickInterval)
 }, TUNNEL_CONFIG.loaderStartDelay)

 return () => {
 clearTimeout(timeout)
 if (interval) clearInterval(interval)
 }
 }, [])

 const handleComplete = () => {
 setIsComplete(true)
 if (onComplete) onComplete()
 }

 return (
 <div className="relative h-screen w-full overflow-hidden">
 {children}
 {!isComplete && (
 <div className="absolute inset-0 z-10">
 <NumericTunnelCanvas loaderValue={loaderValue} onComplete={handleComplete} />
 </div>
 )}
 </div>
 )
}
