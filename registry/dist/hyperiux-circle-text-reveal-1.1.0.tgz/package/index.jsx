// Built using Hyperiux Vault: https://vault.hyperiux.com

'use client'

import { useState, useEffect, useRef } from'react';
import { motion } from 'motion/react';
import { createSuspendedRaf } from './createSuspendedRaf';

/**
 * @typedef {{ x: number | null, y: number | null }} MousePosition
 */

/** @returns {MousePosition} */
function useMousePosition() {
 const [mousePosition, setMousePosition] = useState(/** @type {MousePosition} */ ({ x: null, y: null }));

 useEffect(() => {
 /** @param {MouseEvent} e */
 const updateMousePosition = (e) => {
 setMousePosition({ x: e.clientX, y: e.clientY });
 };
 window.addEventListener('mousemove', updateMousePosition);
 return () => window.removeEventListener('mousemove', updateMousePosition);
 }, []);

 return mousePosition;
}

function useIsPointerFine() {
 const [isPointerFine, setIsPointerFine] = useState(
 () => typeof window !== 'undefined'
 && window.matchMedia('(pointer: fine)').matches
 );

 useEffect(() => {
 const mq = window.matchMedia('(pointer: fine)');
 /** @param {MediaQueryListEvent} e */
 const handler = (e) => setIsPointerFine(e.matches);
 mq.addEventListener('change', handler);
 return () => mq.removeEventListener('change', handler);
 }, []);

 return isPointerFine;
}

function usePrefersReducedMotion() {
 const [prefersReducedMotion, setPrefersReducedMotion] = useState(
 () => typeof window !== 'undefined'
 && window.matchMedia('(prefers-reduced-motion: reduce)').matches
 );

 useEffect(() => {
 const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
 /** @param {MediaQueryListEvent} e */
 const handler = (e) => setPrefersReducedMotion(e.matches);
 mq.addEventListener('change', handler);
 return () => mq.removeEventListener('change', handler);
 }, []);

 return prefersReducedMotion;
}

/**
 * @typedef {Object} CircleTextRevealProps
 * @property {string} [textColor]
 * @property {string} [Text]
 * @property {string} [revealText]
 * @property {string} [circleColorBg]
 * @property {string} [RevealedTextColor]
 */

/** @param {CircleTextRevealProps} props */
export default function CircleTextReveal({
 textColor ='#111',
 Text="Some ideas only bloom when you move toward them.",
 revealText="The hidden layer has been waiting for your cursor.",
 circleColorBg ='#E76F2E',
 RevealedTextColor ='#fefefe'
}) {
 const sectionRef = useRef(/** @type {HTMLElement | null} */ (null));
 const [isHovered, setIsHovered] = useState(false);
 const { x, y } = useMousePosition();
 const isPointerFine = useIsPointerFine();
 const prefersReducedMotion = usePrefersReducedMotion();

 const [smoothPos, setSmoothPos] = useState(/** @type {{ x: number, y: number } | null} */ (null));

 const size = isHovered ? 500 : 40;

 useEffect(() => {
 if (!isPointerFine) return;

 /** @type {(start: number, end: number, factor: number) => number} */
 const lerp = (start, end, factor) => start + (end - start) * factor;
 const lerpFactor = prefersReducedMotion ? 1 : 0.15;

 const loop = createSuspendedRaf({
 root: sectionRef.current,
 onFrame: () => {
 setSmoothPos((prev) => {
 if (x === null || y === null) return prev;
 if (prev === null) return { x, y };
 return {
 x: lerp(prev.x, x, lerpFactor),
 y: lerp(prev.y, y, lerpFactor),
 };
 });
 },
 });

 loop.start();

 return () => loop.destroy();
 }, [x, y, isPointerFine, prefersReducedMotion]);

 return (
 <section ref={sectionRef} className="w-screen h-screen flex items-center justify-center text-[7vw] text-center px-[5vw] bg-[#fefefe] relative overflow-hidden">

 {(!isPointerFine) && (
 <div className="absolute hidden max-[1025px]:flex max-md:flex inset-0 z-20 top-[30%]  items-center justify-center px-8 text-center pointer-events-none">
 <div className="flex max-w-sm flex-col items-center gap-3">
 <p className="text-[4vw] leading-[1.2]!" style={{ color: `${textColor}` }}>
 Open on desktop to reveal the text underneath.
 </p>
 </div>
 </div>
 )}

 {/* ── Masked layer - desktop/mouse only, hidden until first mouse move ── */}
 {isPointerFine && smoothPos !== null && (
 <motion.div
 className="absolute inset-0 flex items-center justify-center z-10"
 style={{
 WebkitMaskImage:'radial-gradient(circle at center, black 50%, transparent 51%)',
 WebkitMaskRepeat:'no-repeat',
 }}
 animate={/** @type {import('motion/react').TargetAndTransition} */ ({
 WebkitMaskPosition: `${smoothPos.x - size / 2}px ${smoothPos.y - size / 2}px`,
 WebkitMaskSize: `${size}px ${size}px`,
 })}
 transition={
 prefersReducedMotion
 ? { type:'tween', ease:'linear', duration: 0 }
 : { type:'tween', ease:'backOut', duration: 0.5 }
 }
 >
 <div className="absolute inset-0" style={{ backgroundColor: circleColorBg }} />

 <h2
 className="relative z-10 leading-tight cursor-default select-none"
 style={{ color: RevealedTextColor }}
 onMouseEnter={() => setIsHovered(true)}
 onMouseLeave={() => setIsHovered(false)}
 >
 {revealText}
 </h2>
 </motion.div>
 )}


 <div className="relative z-0">
 <h1
 className="leading-tight select-none"
 style={{ color: textColor }}
 >
 {Text}
 </h1>
 </div>
 </section>
 );
}
